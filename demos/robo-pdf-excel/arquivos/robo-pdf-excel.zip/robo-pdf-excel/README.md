# Robô PDF → Excel

Lê uma pasta de PDFs de fornecedores (notas de serviço, pedidos de compra, faturas),
tira de cada um fornecedor, CNPJ, número, emissão, vencimento, itens e valores,
confere as contas e entrega um `relatorio.xlsx` pronto para abrir no Excel.

*Projeto demonstrativo: fornecedores, CNPJs e valores dos PDFs de exemplo são fictícios.*

## Como rodar (3 passos)

1. Instale o Python 3.10 ou mais novo e as bibliotecas:
   ```
   pip install -r requirements.txt
   ```
2. Coloque os PDFs na pasta `entrada/` (ou em qualquer pasta sua).
3. Rode o robô:
   ```
   python robo.py
   ```
   ou, escolhendo pasta e arquivo de saída:
   ```
   python robo.py --pasta "C:\Notas\marco" --saida "C:\Relatorios\marco.xlsx"
   ```

A planilha sai em `saida/relatorio.xlsx`.

## O que tem na planilha

| Aba | Conteúdo |
|---|---|
| Painel | Cartões de resumo, total por fornecedor e por mês, dois gráficos nativos do Excel |
| Documentos | Uma linha por PDF, formatada como Tabela (filtro, ordenação, status colorido) |
| Itens | Uma linha por item de cada documento |
| Pendências | O que não bateu: soma dos itens ≠ total, vencimento antes da emissão, CNPJ com dígito errado, campo não encontrado, PDF ilegível |

## Conferências feitas

- Quantidade × valor unitário = total de cada item
- Soma dos itens + frete − desconto = total do documento (tolerância de 1 centavo)
- Vencimento não pode ser anterior à emissão; emissão não pode estar no futuro
- Dígitos verificadores do CNPJ
- Campos obrigatórios presentes

## Adaptar para outro fornecedor

Os rótulos ficam no topo de `robo.py` (`RE_EMISSAO`, `RE_VENCIMENTO`, `RE_TOTAL`...).
Se um fornecedor novo escreve "Data limite" em vez de "Vencimento", basta incluir o
rótulo na lista. Troque `CNPJ_EMPRESA` pelo CNPJ da sua empresa para o robô não
confundir comprador com fornecedor.

PDFs escaneados (imagem) precisam de OCR antes; este robô lê PDFs com texto.

## Arquivos

- `robo.py`: o robô
- `gerar_pdfs.py`: gera os 12 PDFs fictícios de teste em `entrada/`
- `requirements.txt`: dependências
