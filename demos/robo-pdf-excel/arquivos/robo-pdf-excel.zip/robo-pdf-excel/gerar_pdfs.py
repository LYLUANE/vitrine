# -*- coding: utf-8 -*-
"""
Gera 12 PDFs FICTÍCIOS (notas de serviço, pedidos de compra e faturas) para
testar o robô. Fornecedores, CNPJs e valores são inventados.

Três layouts diferentes, de propósito:
  A) Nota de serviço com tabela de grade
  B) Pedido de compra com quadro de dados e frete
  C) Fatura enxuta, sem grade, data por extenso

Três documentos saem com problema para o robô apontar em "Pendências":
  - soma dos itens diferente do total
  - vencimento anterior à emissão
  - CNPJ com dígito verificador errado
"""
from datetime import date
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.platypus import Table, TableStyle

PASTA = Path(__file__).parent / "entrada"
MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho",
         "agosto", "setembro", "outubro", "novembro", "dezembro"]


def dv_cnpj(base12: str) -> str:
    """Calcula os 2 dígitos verificadores de um CNPJ."""
    def dig(nums, pesos):
        s = sum(int(n) * p for n, p in zip(nums, pesos)) % 11
        return "0" if s < 2 else str(11 - s)
    d1 = dig(base12, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])
    d2 = dig(base12 + d1, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])
    return d1 + d2


def fmt_cnpj(base12: str, dv: str | None = None) -> str:
    c = base12 + (dv if dv is not None else dv_cnpj(base12))
    return f"{c[:2]}.{c[2:5]}.{c[5:8]}/{c[8:12]}-{c[12:]}"


def brl(v: float) -> str:
    s = f"{v:,.2f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".")


def dt(d: date) -> str:
    return d.strftime("%d/%m/%Y")


def extenso(d: date) -> str:
    return f"{d.day:02d} de {MESES[d.month - 1]} de {d.year}"


CLIENTE = ("Casa Aurora Restaurantes Ltda", fmt_cnpj("417290530001"))

FORNECEDORES = {
    "tecnolar": ("Tecnolar Manutenção Predial Ltda", "283746190001",
                 "Rua das Acácias, 410 - Centro - Botucatu/SP"),
    "ventura": ("Ventura Climatização e Serviços ME", "395817260001",
                "Av. Dom Lúcio, 1288 - Vila Assunção - Botucatu/SP"),
    "pontofirme": ("Papelaria Ponto Firme Comércio Ltda", "174902350001",
                   "Rua Amando de Barros, 77 - Centro - Botucatu/SP"),
    "graobom": ("Grão Bom Distribuidora de Alimentos Ltda", "506118470001",
                "Rod. Marechal Rondon, km 252 - Galpão 3 - Botucatu/SP"),
    "oficina": ("Oficina Digital Soluções em TI", "621530980001",
                "Rua Curuzu, 155 - sala 4 - Botucatu/SP"),
    "limpamais": ("Limpa Mais Higienização Profissional", "738244610001",
                  "Rua Major Matheus, 902 - Botucatu/SP"),
}

# (arquivo, layout, fornecedor, numero, emissao, vencimento, itens, extras)
# itens: (codigo, descricao, qtd, unidade, valor_unit)
DOCS = [
    ("NS-0412_tecnolar.pdf", "A", "tecnolar", "000412", date(2026, 1, 8), date(2026, 2, 7),
     [("", "Troca de reatores e lâmpadas LED - salão", 18, "un", 42.50),
      ("", "Reparo de tomadas e disjuntores - cozinha", 6, "h", 95.00),
      ("", "Visita técnica emergencial (sábado)", 1, "un", 180.00)], {}),
    ("PC-2026-0041_pontofirme.pdf", "B", "pontofirme", "PC-2026-0041", date(2026, 1, 14), date(2026, 2, 13),
     [("PF-1102", "Papel A4 75g - caixa com 10 resmas", 3, "cx", 249.90),
      ("PF-2210", "Bobina térmica 80mm x 40m", 30, "un", 6.80),
      ("PF-3305", "Caneta esferográfica azul - cx 50", 2, "cx", 38.00),
      ("PF-4120", "Etiqueta adesiva 100x50 - rolo", 8, "un", 27.50)], {"frete": 35.00}),
    ("F-1187_oficina.pdf", "C", "oficina", "F-1187", date(2026, 1, 22), date(2026, 2, 5),
     [("", "Suporte técnico mensal - plano básico", 1, "mês", 650.00),
      ("", "Formatação e backup de notebook", 2, "un", 160.00),
      ("", "Cabo de rede Cat6 instalado", 25, "m", 9.40)], {}),
    ("PC-2026-0057_graobom.pdf", "B", "graobom", "PC-2026-0057", date(2026, 2, 3), date(2026, 3, 5),
     [("GB-0011", "Arroz agulhinha tipo 1 - fardo 30kg", 6, "fd", 148.00),
      ("GB-0204", "Feijão carioca - fardo 30kg", 4, "fd", 189.00),
      ("GB-0350", "Óleo de soja 900ml - cx 20", 5, "cx", 132.50),
      ("GB-0712", "Farinha de trigo especial 25kg", 3, "sc", 96.00)],
     {"frete": 80.00, "total_errado": 3088.50}),  # ERRO: soma não bate
    ("NS-0431_ventura.pdf", "A", "ventura", "000431", date(2026, 2, 10), date(2026, 3, 12),
     [("", "Higienização de split 12.000 BTUs", 4, "un", 180.00),
      ("", "Higienização de split 24.000 BTUs", 2, "un", 260.00),
      ("", "Recarga de gás R410A", 1, "un", 390.00)], {}),
    ("F-0093_limpamais.pdf", "C", "limpamais", "F-0093", date(2026, 2, 18), date(2026, 3, 4),
     [("", "Limpeza pós-obra - salão principal", 1, "serv", 1450.00),
      ("", "Limpeza de coifa e duto", 2, "un", 380.00),
      ("", "Lavagem de estofados", 12, "un", 45.00)], {}),
    ("NS-0447_tecnolar.pdf", "A", "tecnolar", "000447", date(2026, 3, 2), date(2026, 4, 1),
     [("", "Pintura de parede externa (fachada)", 64, "m²", 28.00),
      ("", "Impermeabilização de laje - área técnica", 18, "m²", 54.00)], {}),
    ("PC-2026-0078_pontofirme.pdf", "B", "pontofirme", "PC-2026-0078", date(2026, 3, 9), date(2026, 4, 8),
     [("PF-2210", "Bobina térmica 80mm x 40m", 40, "un", 6.80),
      ("PF-5001", "Pasta suspensa kraft - cx 50", 1, "cx", 74.90)], {"frete": 0.0}),
    ("F-1203_oficina.pdf", "C", "oficina", "F-1203", date(2026, 3, 16), date(2026, 3, 6),  # ERRO: vence antes
     [("", "Suporte técnico mensal - plano básico", 1, "mês", 650.00),
      ("", "Instalação de impressora fiscal", 1, "un", 220.00)], {}),
    ("PC-2026-0093_graobom.pdf", "B", "graobom", "PC-2026-0093", date(2026, 3, 24), date(2026, 4, 23),
     [("GB-0011", "Arroz agulhinha tipo 1 - fardo 30kg", 5, "fd", 151.00),
      ("GB-0204", "Feijão carioca - fardo 30kg", 3, "fd", 192.00),
      ("GB-0901", "Açúcar refinado - fardo 30kg", 2, "fd", 118.00)], {"frete": 80.00, "desconto": 40.00}),
    ("NS-0459_ventura.pdf", "A", "ventura", "000459", date(2026, 4, 6), date(2026, 5, 6),
     [("", "Manutenção preventiva câmara fria", 1, "un", 640.00),
      ("", "Troca de ventilador do condensador", 1, "un", 455.00)], {"cnpj_errado": True}),  # ERRO: DV
    ("F-0101_limpamais.pdf", "C", "limpamais", "F-0101", date(2026, 4, 15), date(2026, 4, 29),
     [("", "Limpeza de coifa e duto", 2, "un", 380.00),
      ("", "Higienização de caixa d'água 5.000 L", 1, "un", 420.00)], {}),
]


def tabela(c, dados, larguras, x, y, estilo):
    t = Table(dados, colWidths=larguras)
    t.setStyle(TableStyle(estilo))
    w, h = t.wrapOn(c, 0, 0)
    t.drawOn(c, x, y - h)
    return y - h


def layout_a(c, doc, forn, cnpj, itens, subtotal, total):
    """Nota de serviço: cabeçalho escuro, tabela com grade."""
    W, H = A4
    nome, _, end = forn
    c.setFillColor(colors.HexColor("#1d3557"))
    c.rect(0, H - 38 * mm, W, 38 * mm, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 16)
    c.drawString(18 * mm, H - 16 * mm, nome)
    c.setFont("Helvetica", 9)
    c.drawString(18 * mm, H - 22 * mm, f"CNPJ: {cnpj}")
    c.drawString(18 * mm, H - 27 * mm, end)
    c.setFont("Helvetica-Bold", 12)
    c.drawRightString(W - 18 * mm, H - 16 * mm, f"NOTA DE SERVIÇO Nº {doc[3]}")
    c.setFont("Helvetica", 9)
    c.drawRightString(W - 18 * mm, H - 22 * mm, f"Emissão: {dt(doc[4])}")
    c.setFillColor(colors.black)
    y = H - 50 * mm
    c.setFont("Helvetica-Bold", 9)
    c.drawString(18 * mm, y, "TOMADOR DO SERVIÇO")
    c.setFont("Helvetica", 9)
    c.drawString(18 * mm, y - 5 * mm, f"{CLIENTE[0]}  -  CNPJ {CLIENTE[1]}")
    y -= 16 * mm
    dados = [["Descrição do serviço", "Qtd", "Un", "Valor unit.", "Total"]]
    for _, d, q, u, v in itens:
        dados.append([d, str(q), u, brl(v), brl(q * v)])
    y = tabela(c, dados, [92 * mm, 14 * mm, 12 * mm, 28 * mm, 28 * mm], 18 * mm, y, [
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#9aa5b1")),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8edf3")),
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 9),
        ("FONT", (0, 1), (-1, -1), "Helvetica", 9),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
    ])
    y -= 10 * mm
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(W - 18 * mm, y, f"Total geral: R$ {brl(total)}")
    c.setFont("Helvetica", 10)
    c.drawRightString(W - 18 * mm, y - 7 * mm, f"Vencimento: {dt(doc[5])}")
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.grey)
    c.drawString(18 * mm, 15 * mm, "Documento fictício gerado para demonstração. Pagamento via boleto ou PIX.")


def layout_b(c, doc, forn, cnpj, itens, subtotal, total, ex):
    """Pedido de compra: quadro de dados, código do item, frete e desconto."""
    W, H = A4
    nome, _, end = forn
    c.setFont("Helvetica-Bold", 18)
    c.drawString(18 * mm, H - 20 * mm, "PEDIDO DE COMPRA")
    c.setFont("Helvetica", 10)
    c.drawRightString(W - 18 * mm, H - 20 * mm, f"Pedido nº {doc[3]}")
    c.setStrokeColor(colors.HexColor("#c0392b"))
    c.setLineWidth(2)
    c.line(18 * mm, H - 24 * mm, W - 18 * mm, H - 24 * mm)
    dados = [
        ["Fornecedor:", nome, "Data do pedido:", dt(doc[4])],
        ["CNPJ:", cnpj, "Data de vencimento:", dt(doc[5])],
        ["Endereço:", end, "", ""],
        ["Comprador:", CLIENTE[0], "CNPJ comprador:", CLIENTE[1]],
    ]
    y = tabela(c, dados, [24 * mm, 76 * mm, 36 * mm, 38 * mm], 18 * mm, H - 30 * mm, [
        ("BOX", (0, 0), (-1, -1), 0.8, colors.black),
        ("FONT", (0, 0), (0, -1), "Helvetica-Bold", 8.5),
        ("FONT", (2, 0), (2, -1), "Helvetica-Bold", 8.5),
        ("FONT", (1, 0), (1, -1), "Helvetica", 8.5),
        ("FONT", (3, 0), (3, -1), "Helvetica", 8.5),
        ("SPAN", (1, 2), (3, 2)),
    ])
    y -= 10 * mm
    dados = [["Código", "Descrição", "Qtd", "Un", "Preço unit.", "Subtotal"]]
    for cod, d, q, u, v in itens:
        dados.append([cod, d, str(q), u, f"R$ {brl(v)}", f"R$ {brl(q * v)}"])
    y = tabela(c, dados, [20 * mm, 74 * mm, 12 * mm, 12 * mm, 28 * mm, 28 * mm], 18 * mm, y, [
        ("LINEBELOW", (0, 0), (-1, 0), 1, colors.black),
        ("LINEBELOW", (0, 1), (-1, -1), 0.3, colors.HexColor("#bbbbbb")),
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 8.5),
        ("FONT", (0, 1), (-1, -1), "Helvetica", 8.5),
        ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
    ])
    y -= 8 * mm
    linhas = [("Soma dos itens", subtotal), ("Frete", ex.get("frete", 0.0))]
    if ex.get("desconto"):
        linhas.append(("Desconto", ex["desconto"]))
    c.setFont("Helvetica", 9.5)
    for rot, v in linhas:
        c.drawString(130 * mm, y, rot)
        c.drawRightString(W - 18 * mm, y, f"R$ {brl(v)}")
        y -= 5.5 * mm
    c.setFont("Helvetica-Bold", 11)
    c.drawString(130 * mm, y - 1 * mm, "Valor total do pedido")
    c.drawRightString(W - 18 * mm, y - 1 * mm, f"R$ {brl(total)}")
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.grey)
    c.drawString(18 * mm, 15 * mm, "Pedido fictício para demonstração. Condição: 30 dias.")


def layout_c(c, doc, forn, cnpj, itens, subtotal, total):
    """Fatura enxuta: sem grade, data por extenso."""
    W, H = A4
    nome, _, end = forn
    c.setFillColor(colors.HexColor("#2a9d8f"))
    c.circle(24 * mm, H - 22 * mm, 6 * mm, fill=1, stroke=0)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(34 * mm, H - 20 * mm, nome)
    c.setFont("Helvetica", 8.5)
    c.drawString(34 * mm, H - 25 * mm, f"{end}  |  CNPJ {cnpj}")
    c.setFont("Helvetica-Bold", 22)
    c.setFillColor(colors.HexColor("#2a9d8f"))
    c.drawString(18 * mm, H - 48 * mm, f"Fatura #{doc[3]}")
    c.setFillColor(colors.black)
    c.setFont("Helvetica", 10)
    c.drawString(18 * mm, H - 56 * mm, f"Emitida em {extenso(doc[4])}")
    c.drawString(18 * mm, H - 61 * mm, f"Cliente: {CLIENTE[0]}")
    y = H - 76 * mm
    c.setFont("Helvetica-Bold", 9)
    c.drawString(18 * mm, y, "Item")
    c.drawString(28 * mm, y, "Descrição")
    c.drawRightString(132 * mm, y, "Qtd")
    c.drawString(135 * mm, y, "Un")
    c.drawRightString(170 * mm, y, "Unitário")
    c.drawRightString(W - 18 * mm, y, "Valor")
    c.setFont("Helvetica", 9.5)
    for i, (_, d, q, u, v) in enumerate(itens, 1):
        y -= 7 * mm
        c.drawString(18 * mm, y, f"{i:02d}")
        c.drawString(28 * mm, y, d)
        c.drawRightString(132 * mm, y, str(q))
        c.drawString(135 * mm, y, u)
        c.drawRightString(170 * mm, y, brl(v))
        c.drawRightString(W - 18 * mm, y, brl(q * v))
    y -= 6 * mm
    c.setStrokeColor(colors.HexColor("#2a9d8f"))
    c.line(120 * mm, y, W - 18 * mm, y)
    y -= 8 * mm
    c.setFont("Helvetica-Bold", 12)
    c.drawString(120 * mm, y, "Total a pagar")
    c.drawRightString(W - 18 * mm, y, f"R$ {brl(total)}")
    c.setFont("Helvetica", 10)
    c.drawString(120 * mm, y - 7 * mm, f"Pagar até {dt(doc[5])}")
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.grey)
    c.drawString(18 * mm, 15 * mm, "Fatura fictícia para demonstração. Chave PIX: o CNPJ acima.")


def main():
    PASTA.mkdir(parents=True, exist_ok=True)
    for doc in DOCS:
        arq, lay, chave, _, _, _, itens, ex = doc
        forn = FORNECEDORES[chave]
        base = forn[1]
        cnpj = fmt_cnpj(base)
        if ex.get("cnpj_errado"):
            certo = dv_cnpj(base)
            cnpj = fmt_cnpj(base, certo[0] + str((int(certo[1]) + 3) % 10))
        subtotal = round(sum(q * v for _, _, q, _, v in itens), 2)
        total = ex.get("total_errado") or round(subtotal + ex.get("frete", 0) - ex.get("desconto", 0), 2)
        c = canvas.Canvas(str(PASTA / arq), pagesize=A4)
        c.setTitle(arq)
        c.setAuthor(forn[0])
        if lay == "A":
            layout_a(c, doc, forn, cnpj, itens, subtotal, total)
        elif lay == "B":
            layout_b(c, doc, forn, cnpj, itens, subtotal, total, ex)
        else:
            layout_c(c, doc, forn, cnpj, itens, subtotal, total)
        c.save()
        print("gerado", arq)


if __name__ == "__main__":
    main()
