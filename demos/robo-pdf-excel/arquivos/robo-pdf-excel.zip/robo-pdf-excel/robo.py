# -*- coding: utf-8 -*-
"""
Robô PDF -> Excel
=================
Lê todos os PDFs de uma pasta (notas de serviço, pedidos de compra, faturas),
extrai os dados principais, confere as contas e gera uma planilha pronta:

  Documentos  - uma linha por PDF, formatada como tabela do Excel
  Itens       - uma linha por item de cada documento
  Painel      - totais por fornecedor e por mês, com gráficos nativos
  Pendências  - tudo o que não bateu (soma, datas, CNPJ, campo faltando)

Uso:
    python robo.py                       # lê ./entrada e grava ./saida/relatorio.xlsx
    python robo.py --pasta notas --saida relatorios/marco.xlsx
"""
from __future__ import annotations

import argparse
import re
import sys
import time
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path

import pdfplumber
from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

# CNPJ da própria empresa (o comprador). Aparece nos documentos, mas não é o
# fornecedor, então o robô ignora esse número ao procurar o CNPJ do emissor.
CNPJ_EMPRESA = "41.729.053/0001-25"

TOLERANCIA = 0.01  # diferença máxima aceita entre soma e total (centavos)

MESES = {"janeiro": 1, "fevereiro": 2, "março": 3, "marco": 3, "abril": 4,
         "maio": 5, "junho": 6, "julho": 7, "agosto": 8, "setembro": 9,
         "outubro": 10, "novembro": 11, "dezembro": 12}
MESES_CURTOS = ["jan", "fev", "mar", "abr", "mai", "jun",
                "jul", "ago", "set", "out", "nov", "dez"]

# ---------------------------------------------------------------------------
# Padrões de texto. Cada campo tem uma lista de rótulos possíveis porque cada
# fornecedor escreve de um jeito ("Emissão", "Data do pedido", "Emitida em"...).
# ---------------------------------------------------------------------------
DINHEIRO = r"(?:R\$\s*)?(\d{1,3}(?:\.\d{3})*,\d{2})"
DATA = r"(\d{2}/\d{2}/\d{4}|\d{1,2} de [a-zç]+ de \d{4})"
RE_CNPJ = re.compile(r"\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}")

RE_NUMERO = re.compile(r"(?:n[º°o]\.?|#)\s*([A-Z]{0,3}-?\d[\w-]*)", re.I)
RE_EMISSAO = [re.compile(p + r"\s*:?\s*" + DATA, re.I) for p in
              (r"Data de emiss[ãa]o", r"Emiss[ãa]o", r"Data do pedido", r"Emitida em")]
RE_VENCIMENTO = [re.compile(p + r"\s*:?\s*" + DATA, re.I) for p in
                 (r"Data de vencimento", r"Vencimento", r"Pagar at[ée]", r"Vence em")]
RE_TOTAL = [re.compile(p + r"\s*:?\s*" + DINHEIRO, re.I) for p in
            (r"Valor total do pedido", r"Total geral", r"Total a pagar", r"Valor total")]
RE_FRETE = re.compile(r"^Frete\s+" + DINHEIRO, re.I | re.M)
RE_DESCONTO = re.compile(r"^Desconto\s+" + DINHEIRO, re.I | re.M)
RE_FORNECEDOR = re.compile(r"(?:Fornecedor|Raz[ãa]o social)\s*:\s*(.+?)(?:\s{2,}|\s+Data|\s+CNPJ|$)", re.I | re.M)

# Linha de item: [código ou nº]  descrição  qtd  unidade  unitário  total
RE_ITEM = re.compile(
    r"^(?:(?P<cod>[A-Z]{2,4}-\d{3,5}|\d{2})\s+)?"
    r"(?P<desc>.+?)\s+"
    r"(?P<qtd>\d+(?:,\d+)?)\s+"
    r"(?P<un>[^\d\s]{1,5})\s+"
    r"(?:R\$\s*)?(?P<unit>\d{1,3}(?:\.\d{3})*,\d{2})\s+"
    r"(?:R\$\s*)?(?P<tot>\d{1,3}(?:\.\d{3})*,\d{2})$"
)
RE_INICIO_ITENS = re.compile(r"descri[çc][ãa]o", re.I)
RE_FIM_ITENS = re.compile(r"^(soma dos itens|subtotal|total|valor total)", re.I)


@dataclass
class Item:
    codigo: str
    descricao: str
    qtd: float
    unidade: str
    unitario: float
    total: float


@dataclass
class Documento:
    arquivo: str
    tipo: str = ""
    fornecedor: str = ""
    cnpj: str = ""
    numero: str = ""
    emissao: date | None = None
    vencimento: date | None = None
    frete: float = 0.0
    desconto: float = 0.0
    total: float | None = None
    itens: list[Item] = field(default_factory=list)
    pendencias: list[tuple[str, str]] = field(default_factory=list)

    @property
    def soma_itens(self) -> float:
        return round(sum(i.total for i in self.itens), 2)


# ---------------------------------------------------------------------------
# Conversões
# ---------------------------------------------------------------------------
def para_float(txt: str) -> float:
    """'1.234,56' -> 1234.56"""
    return float(txt.replace(".", "").replace(",", "."))


def para_data(txt: str) -> date | None:
    """Aceita '05/03/2026' e '5 de março de 2026'."""
    txt = txt.strip().lower()
    try:
        if "/" in txt:
            return datetime.strptime(txt, "%d/%m/%Y").date()
        dia, _, mes, _, ano = txt.split()
        return date(int(ano), MESES[mes], int(dia))
    except (ValueError, KeyError):
        return None


def cnpj_valido(cnpj: str) -> bool:
    """Confere os dois dígitos verificadores do CNPJ."""
    n = re.sub(r"\D", "", cnpj)
    if len(n) != 14 or len(set(n)) == 1:
        return False

    def dig(base, pesos):
        s = sum(int(a) * b for a, b in zip(base, pesos)) % 11
        return "0" if s < 2 else str(11 - s)

    d1 = dig(n[:12], [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])
    d2 = dig(n[:12] + d1, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])
    return n[12:] == d1 + d2


def primeiro(padroes, texto):
    """Devolve o primeiro grupo encontrado na lista de padrões."""
    for p in padroes:
        m = p.search(texto)
        if m:
            return m.group(1)
    return None


# ---------------------------------------------------------------------------
# Extração
# ---------------------------------------------------------------------------
def ler_pdf(caminho: Path) -> Documento:
    doc = Documento(arquivo=caminho.name)
    with pdfplumber.open(caminho) as pdf:
        texto = "\n".join(p.extract_text() or "" for p in pdf.pages)
    linhas = [l.strip() for l in texto.splitlines() if l.strip()]

    # Tipo do documento (só para leitura humana na planilha)
    cab = texto[:400].lower()
    doc.tipo = ("Pedido de compra" if "pedido" in cab else
                "Nota de serviço" if "nota de servi" in cab else
                "Fatura" if "fatura" in cab else "Outro")

    # Fornecedor: rótulo explícito ou, na falta dele, a primeira linha
    m = RE_FORNECEDOR.search(texto)
    doc.fornecedor = (m.group(1) if m else linhas[0] if linhas else "").strip()

    # CNPJ do emissor: o primeiro que não seja o da própria empresa
    for c in RE_CNPJ.findall(texto):
        if c != CNPJ_EMPRESA:
            doc.cnpj = c
            break

    m = RE_NUMERO.search(texto)
    doc.numero = m.group(1) if m else ""

    if (d := primeiro(RE_EMISSAO, texto)):
        doc.emissao = para_data(d)
    if (d := primeiro(RE_VENCIMENTO, texto)):
        doc.vencimento = para_data(d)
    if (v := primeiro(RE_TOTAL, texto)):
        doc.total = para_float(v)
    if (m := RE_FRETE.search(texto)):
        doc.frete = para_float(m.group(1))
    if (m := RE_DESCONTO.search(texto)):
        doc.desconto = para_float(m.group(1))

    # Itens: linhas entre o cabeçalho da tabela e a linha de totais
    dentro = False
    for l in linhas:
        if not dentro:
            dentro = bool(RE_INICIO_ITENS.search(l)) and not RE_ITEM.match(l)
            continue
        if RE_FIM_ITENS.match(l):
            break
        m = RE_ITEM.match(l)
        if m:
            cod = m["cod"] or ""
            doc.itens.append(Item(
                codigo=cod if not cod.isdigit() else "",
                descricao=m["desc"].strip(),
                qtd=para_float(m["qtd"]) if "," in m["qtd"] else float(m["qtd"]),
                unidade=m["un"],
                unitario=para_float(m["unit"]),
                total=para_float(m["tot"]),
            ))
    return doc


# ---------------------------------------------------------------------------
# Validação
# ---------------------------------------------------------------------------
def validar(doc: Documento) -> None:
    p = doc.pendencias
    for campo, rotulo in (("fornecedor", "Fornecedor"), ("cnpj", "CNPJ"), ("numero", "Número"),
                          ("emissao", "Data de emissão"), ("vencimento", "Vencimento"),
                          ("total", "Valor total")):
        if not getattr(doc, campo):
            p.append(("Campo não encontrado", f"{rotulo} não foi localizado no PDF"))
    if not doc.itens:
        p.append(("Sem itens", "Nenhuma linha de item reconhecida"))

    if doc.cnpj and not cnpj_valido(doc.cnpj):
        p.append(("CNPJ inválido", f"{doc.cnpj}: dígito verificador não confere"))

    for i in doc.itens:  # qtd x unitário de cada linha
        if abs(i.qtd * i.unitario - i.total) > TOLERANCIA:
            p.append(("Item com conta errada",
                      f"{i.descricao}: {i.qtd:g} x {i.unitario:.2f} ≠ {i.total:.2f}"))

    if doc.total is not None and doc.itens:
        esperado = round(doc.soma_itens + doc.frete - doc.desconto, 2)
        if abs(esperado - doc.total) > TOLERANCIA:
            p.append(("Soma não confere",
                      f"Itens + frete - desconto = R$ {brl(esperado)}, "
                      f"documento diz R$ {brl(doc.total)} (dif. R$ {brl(doc.total - esperado)})"))

    if doc.emissao and doc.vencimento and doc.vencimento < doc.emissao:
        p.append(("Datas inconsistentes",
                  f"Vencimento {doc.vencimento:%d/%m/%Y} é anterior à emissão {doc.emissao:%d/%m/%Y}"))
    if doc.emissao and doc.emissao > date.today():
        p.append(("Data no futuro", f"Emissão {doc.emissao:%d/%m/%Y} ainda não aconteceu"))


def brl(v: float) -> str:
    s = f"{v:,.2f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".")


# ---------------------------------------------------------------------------
# Planilha
# ---------------------------------------------------------------------------
AZUL = "1F4E5F"
FMT_REAL = '"R$" #,##0.00'
FMT_DATA = "DD/MM/YYYY"
FINA = Side(style="thin", color="D0D7DE")


def ajustar_larguras(ws, larguras):
    for i, w in enumerate(larguras, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def aba_tabela(ws, nome_tabela, cabecalho, linhas, formatos, larguras, estilo="TableStyleMedium2"):
    """Escreve linhas e transforma o intervalo em Tabela do Excel (filtros, listras)."""
    ws.append(cabecalho)
    for l in linhas:
        ws.append(l)
    for col, fmt in formatos.items():
        for (c,) in ws.iter_rows(min_row=2, min_col=col, max_col=col):
            c.number_format = fmt
    if linhas:
        ref = f"A1:{get_column_letter(len(cabecalho))}{len(linhas) + 1}"
        t = Table(displayName=nome_tabela, ref=ref)
        t.tableStyleInfo = TableStyleInfo(name=estilo, showRowStripes=True)
        ws.add_table(t)
    ws.freeze_panes = "A2"
    ajustar_larguras(ws, larguras)
    for c in ws[1]:
        c.alignment = Alignment(vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 30


def gerar_planilha(docs: list[Documento], destino: Path) -> None:
    wb = Workbook()

    # --- Documentos -------------------------------------------------------
    ws = wb.active
    ws.title = "Documentos"
    cab = ["Arquivo", "Tipo", "Fornecedor", "CNPJ", "Número", "Emissão", "Vencimento",
           "Mês", "Qtd itens", "Soma itens", "Frete", "Desconto", "Total", "Status"]
    linhas = []
    for d in docs:
        mes = f"{MESES_CURTOS[d.emissao.month - 1]}/{d.emissao.year}" if d.emissao else ""
        linhas.append([d.arquivo, d.tipo, d.fornecedor, d.cnpj, d.numero, d.emissao, d.vencimento,
                       mes, len(d.itens), d.soma_itens, d.frete, d.desconto, d.total,
                       "Pendência" if d.pendencias else "OK"])
    aba_tabela(ws, "tbDocumentos", cab, linhas,
               {6: FMT_DATA, 7: FMT_DATA, 10: FMT_REAL, 11: FMT_REAL, 12: FMT_REAL, 13: FMT_REAL},
               [30, 16, 40, 20, 15, 12, 12, 10, 9, 14, 11, 11, 14, 12])
    # Destaque visual do status
    n = len(linhas) + 1
    ws.conditional_formatting.add(f"N2:N{n}", FormulaRule(
        formula=['$N2="Pendência"'], fill=PatternFill("solid", fgColor="FBE3D6"),
        font=Font(color="9C2A00", bold=True)))
    ws.conditional_formatting.add(f"N2:N{n}", FormulaRule(
        formula=['$N2="OK"'], fill=PatternFill("solid", fgColor="DDEFE3"), font=Font(color="1E6B3A")))

    # --- Itens ------------------------------------------------------------
    wi = wb.create_sheet("Itens")
    linhas = [[d.arquivo, d.numero, d.fornecedor, i.codigo, i.descricao, i.qtd, i.unidade,
               i.unitario, i.total] for d in docs for i in d.itens]
    aba_tabela(wi, "tbItens",
               ["Arquivo", "Número", "Fornecedor", "Código", "Descrição", "Qtd", "Un",
                "Valor unit.", "Total item"], linhas,
               {8: FMT_REAL, 9: FMT_REAL}, [30, 15, 40, 10, 46, 7, 6, 13, 13], "TableStyleLight9")

    # --- Painel -----------------------------------------------------------
    wp = wb.create_sheet("Painel")
    wp.sheet_view.showGridLines = False
    validos = [d for d in docs if d.total is not None]
    total_geral = sum(d.total for d in validos)
    wp["B2"] = "Painel de compras e serviços"
    wp["B2"].font = Font(size=18, bold=True, color=AZUL)
    wp["B3"] = f"Gerado pelo robô em {datetime.now():%d/%m/%Y %H:%M} a partir de {len(docs)} PDFs"
    wp["B3"].font = Font(size=10, italic=True, color="666666")

    # Cartões de resumo
    cartoes = [("Total processado", total_geral, FMT_REAL),
               ("Documentos lidos", len(docs), "0"),
               ("Com pendência", sum(1 for d in docs if d.pendencias), "0"),
               ("Fornecedores", len({d.fornecedor for d in docs}), "0")]
    for k, (rot, val, fmt) in enumerate(cartoes):
        col = 2 + k * 2
        r = wp.cell(row=5, column=col, value=rot)
        v = wp.cell(row=6, column=col, value=val)
        r.font = Font(size=9, color="FFFFFF", bold=True)
        v.font = Font(size=16, bold=True, color="FFFFFF")
        v.number_format = fmt
        for c in (r, v):
            c.fill = PatternFill("solid", fgColor=AZUL if k != 2 else "B5471B")
            c.alignment = Alignment(horizontal="left", indent=1)
        wp.merge_cells(start_row=5, start_column=col, end_row=5, end_column=col + 1)
        wp.merge_cells(start_row=6, start_column=col, end_row=6, end_column=col + 1)
        for cc in range(col, col + 2):
            for rr in (5, 6):
                wp.cell(row=rr, column=cc).fill = PatternFill("solid", fgColor=AZUL if k != 2 else "B5471B")
    wp.row_dimensions[6].height = 30

    def bloco(linha0, titulo, cab2, dados):
        wp.cell(row=linha0, column=2, value=titulo).font = Font(bold=True, size=12, color=AZUL)
        for j, h in enumerate(cab2):
            c = wp.cell(row=linha0 + 1, column=2 + j, value=h)
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor=AZUL)
        for i, row in enumerate(dados):
            for j, v in enumerate(row):
                c = wp.cell(row=linha0 + 2 + i, column=2 + j, value=v)
                c.border = Border(bottom=FINA)
                if j == 2:
                    c.number_format = FMT_REAL
                if j == 3:
                    c.number_format = "0.0%"
        fim = linha0 + 2 + len(dados)
        wp.cell(row=fim, column=2, value="Total").font = Font(bold=True)
        wp.cell(row=fim, column=3, value=sum(r[1] for r in dados)).font = Font(bold=True)
        t = wp.cell(row=fim, column=4, value=sum(r[2] for r in dados))
        t.font = Font(bold=True)
        t.number_format = FMT_REAL
        return linha0 + 2, fim - 1

    # Totais por fornecedor (maior primeiro)
    por_forn: dict[str, list] = {}
    for d in validos:
        por_forn.setdefault(d.fornecedor, [0, 0.0])
        por_forn[d.fornecedor][0] += 1
        por_forn[d.fornecedor][1] += d.total
    dados_f = sorted(([f, q, v, v / total_geral] for f, (q, v) in por_forn.items()),
                     key=lambda r: -r[2])
    ini_f, fim_f = bloco(9, "Total por fornecedor", ["Fornecedor", "Docs", "Total", "% do total"], dados_f)

    # Totais por mês de emissão (ordem cronológica)
    por_mes: dict[tuple, list] = {}
    for d in validos:
        if d.emissao:
            k = (d.emissao.year, d.emissao.month)
            por_mes.setdefault(k, [0, 0.0])
            por_mes[k][0] += 1
            por_mes[k][1] += d.total
    dados_m = [[f"{MESES_CURTOS[m - 1]}/{a}", q, v, v / total_geral]
               for (a, m), (q, v) in sorted(por_mes.items())]
    lin_m = fim_f + 4
    ini_m, fim_m = bloco(lin_m, "Total por mês de emissão", ["Mês", "Docs", "Total", "% do total"], dados_m)
    ajustar_larguras(wp, [2, 40, 8, 15, 11, 4, 12, 12, 12])

    # Gráficos nativos do Excel (continuam editáveis no Excel)
    g1 = BarChart()
    g1.type = "bar"
    g1.title = "Total por fornecedor (R$)"
    g1.style = 10
    g1.add_data(Reference(wp, min_col=4, min_row=ini_f, max_row=fim_f), titles_from_data=False)
    g1.set_categories(Reference(wp, min_col=2, min_row=ini_f, max_row=fim_f))
    g1.legend = None
    g1.y_axis.numFmt = '#,##0'
    g1.x_axis.scaling.orientation = "maxMin"  # maior no topo
    g1.series[0].graphicalProperties.solidFill = AZUL
    g1.dataLabels = DataLabelList()
    g1.dataLabels.showVal = True
    g1.dataLabels.numFmt = '#,##0'
    g1.height, g1.width = 8, 17
    wp.add_chart(g1, "G9")

    g2 = BarChart()
    g2.type = "col"
    g2.title = "Total por mês (R$)"
    g2.style = 10
    g2.add_data(Reference(wp, min_col=4, min_row=ini_m, max_row=fim_m), titles_from_data=False)
    g2.set_categories(Reference(wp, min_col=2, min_row=ini_m, max_row=fim_m))
    g2.legend = None
    g2.y_axis.numFmt = '#,##0'
    g2.series[0].graphicalProperties.solidFill = "2A9D8F"
    g2.dataLabels = DataLabelList()
    g2.dataLabels.showVal = True
    g2.dataLabels.numFmt = '#,##0'
    g2.height, g2.width = 8, 17
    wp.add_chart(g2, f"G{lin_m}")

    # --- Pendências -------------------------------------------------------
    wpe = wb.create_sheet("Pendências")
    linhas = [[d.arquivo, d.fornecedor, d.numero, tipo, det] for d in docs for tipo, det in d.pendencias]
    if not linhas:
        linhas = [["-", "-", "-", "Nenhuma", "Todos os documentos conferiram"]]
    aba_tabela(wpe, "tbPendencias", ["Arquivo", "Fornecedor", "Número", "Tipo", "Detalhe"],
               linhas, {}, [30, 40, 15, 22, 80], "TableStyleMedium3")
    wpe.sheet_properties.tabColor = "B5471B"
    wp.sheet_properties.tabColor = AZUL

    wb.move_sheet("Painel", offset=-2)  # Painel como primeira aba
    wb.active = 0
    destino.parent.mkdir(parents=True, exist_ok=True)
    wb.save(destino)


# ---------------------------------------------------------------------------
# Execução
# ---------------------------------------------------------------------------
def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="Lê PDFs de notas/pedidos e gera relatório em Excel.")
    base = Path(__file__).parent
    ap.add_argument("--pasta", type=Path, default=base / "entrada", help="pasta com os PDFs (padrão: entrada)")
    ap.add_argument("--saida", type=Path, default=base / "saida" / "relatorio.xlsx",
                    help="arquivo .xlsx de saída (padrão: saida/relatorio.xlsx)")
    args = ap.parse_args()

    pdfs = sorted(args.pasta.glob("*.pdf"))
    if not pdfs:
        print(f"Nenhum PDF encontrado em {args.pasta}")
        return 1

    inicio = time.perf_counter()
    print(f"Robô PDF -> Excel  |  {len(pdfs)} PDFs em '{args.pasta.name}'\n")
    docs = []
    for caminho in pdfs:
        try:
            d = ler_pdf(caminho)
        except Exception as e:  # PDF corrompido, protegido por senha etc.
            d = Documento(arquivo=caminho.name, pendencias=[("Erro de leitura", str(e))])
        else:
            validar(d)
        docs.append(d)
        marca = "OK " if not d.pendencias else "!! "
        total = f"R$ {brl(d.total):>10}" if d.total is not None else " " * 13
        print(f"  [{marca}] {d.arquivo:<30} {len(d.itens):>2} itens  {total}")
        for tipo, det in d.pendencias:
            print(f"         -> {tipo}: {det}")

    gerar_planilha(docs, args.saida)
    n_pend = sum(1 for d in docs if d.pendencias)
    total = sum(d.total or 0 for d in docs)
    print(f"\n  {len(docs)} documentos  |  {sum(len(d.itens) for d in docs)} itens  |  "
          f"total R$ {brl(total)}  |  {n_pend} com pendência")
    try:  # mostra o caminho curto quando possível
        mostrar = args.saida.resolve().relative_to(Path.cwd())
    except ValueError:
        mostrar = args.saida
    print(f"  Planilha salva em {mostrar}  ({time.perf_counter() - inicio:.1f} s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
